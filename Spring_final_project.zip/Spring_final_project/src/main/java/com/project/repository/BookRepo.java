package com.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.model.Book;

@Repository
public interface BookRepo extends JpaRepository<Book, Integer> 
{
	void deleteByIsbn(int isbn);  
    Book findByTitle(String title);
  
	List<Book> findAllByGenre(String genre);

}

package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.User;

public interface UserRepo<Book> extends JpaRepository<User, Integer>
{

     User findByEmail(String email);

}

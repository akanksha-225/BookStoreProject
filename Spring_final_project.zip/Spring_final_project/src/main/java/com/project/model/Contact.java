package com.project.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Contact
{
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
   private int sr;
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(int sr, String name, String email, String msg) {
		super();
		this.sr = sr;
		this.name = name;
		this.email = email;
		this.msg = msg;
	}
	@Override
	public String toString() {
		return "Contact [sr=" + sr + ", name=" + name + ", email=" + email + ", msg=" + msg + "]";
	}
	public int getSr() {
		return sr;
	}
	public void setSr(int sr) {
		this.sr = sr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	private String name;
	private String email;
	private String msg;
	
}

package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Admin;
import com.project.model.Book;
import com.project.repository.AdminRepo;
import com.project.repository.BookRepo;

@Controller
public class AdminController {
	@Autowired
	AdminRepo ar;

	@RequestMapping("/")
	public String first() {
		return "Main.jsp";
	}

	
	@RequestMapping("/adminlogin")
	public String getLogin(@RequestParam String email, @RequestParam String password) {
		Admin ob = ar.findByEmail(email);
		if (ob != null && ob.getEmail().equals(email) && ob.getPassword().equals(password)) {
			return "bookInsertion.jsp";
		} else {
			return "fail.jsp";
		}

	}
}

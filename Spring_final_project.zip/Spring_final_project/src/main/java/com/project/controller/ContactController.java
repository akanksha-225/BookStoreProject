package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.model.Contact;
import com.project.repository.ContactRepo;

@Controller
public class ContactController 
{
	@Autowired
	ContactRepo cr;
	
	/*
	 * @RequestMapping("/contact") public String getContact() { return
	 * "Contact.jsp"; }
	 */
	
	@RequestMapping("/saveContact")
	public String saveContact(@ModelAttribute Contact c)
	{
		cr.save(c);
		return "sucess.jsp";
		
	}
}

package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Book;
import com.project.model.User;
import com.project.repository.BookRepo;

@Controller
public class BookController {
	@Autowired
	BookRepo br;

	@RequestMapping("/bookinsert")
	public String insert_book(@ModelAttribute Book ob) {
		br.save(ob);
		return "bookInsertion.jsp";
	}

	@RequestMapping("/fetch")
	public String showdata(Model data) {

		List<Book> al = br.findAll();
		data.addAttribute("data", al);
		return "datafetch.jsp";
	}

	@RequestMapping("/Delete/{isbn}")
	public String del(@PathVariable int isbn) {
		br.deleteById(isbn);
		return "redirect:/fetch";
	}

	@RequestMapping("{isbn}")
	public String update(@PathVariable int isbn, Model m) {
		Book ob = br.findById(isbn).orElse(null);
		m.addAttribute("data", ob);
		return "edit.jsp";
	}

	@RequestMapping("/edit/{isbn}")

	public String update(@PathVariable int isbn, @ModelAttribute Book b) {
		Book ob = br.findById(isbn).orElse(null);
		if (ob != null) {
			ob.setAuthor(b.getAuthor());
			ob.setGenre(b.getGenre());
			ob.setPages(b.getPages());
			ob.setPublisher_name(b.getPublisher_name());
			ob.setTitle(b.getTitle());
			ob.setPrice(b.getPrice());
			br.save(ob);
		}
		return "redirect:/fetch";
	}

	@RequestMapping("/search")
	public String search(@RequestParam String title, Model m) {

		Book b = br.findByTitle(title);
		System.out.println(b);
		m.addAttribute("key", b);
		if (b != null) {
			return "searchdata.jsp";
		} else {
			return "fail.jsp";
		}
	}

	@RequestMapping("/FindByGenre/{genre}")
	public String del(@PathVariable String genre, Model m) {
		List<Book> al = br.findAllByGenre(genre);

		m.addAttribute("data", al);

		return "GenreRecords.jsp";
	}

	@RequestMapping("/Userfetch")
	public String userdata(Model data) {

		List<Book> al = br.findAll();
		data.addAttribute("data", al);
		return "FindByGenre/GenreRecords.jsp";
	}

	@RequestMapping("/toCart/{isbn}")
	public String cart(@PathVariable int isbn, Model m) {
		Book ob = br.findById(isbn).orElse(null);
		m.addAttribute("data", ob);
		System.out.println(ob);
		return "NewFile.jsp";
	}

	/*
	 * @RequestMapping("/toCart123/{isbn}") public String mycart(@PathVariable int
	 * isbn, Model m) {
	 * 
	 * List<Book> ob = br.findAllById(isbn); m.addAttribute("data", ob); return
	 * "sucess.jsp";
	 * 
	 * }
	 */
	
	/*
	 * @RequestMapping("/viewrec/{data}") public String mycart(@PathVariable Model
	 * data) { data.addAttribute("m"); return "NewFile.jsp"; }
	 */
	 
}

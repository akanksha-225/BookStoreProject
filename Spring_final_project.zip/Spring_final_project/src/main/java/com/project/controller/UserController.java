package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Book;
import com.project.model.User;
import com.project.repository.UserRepo;

@Controller
public class UserController 
{
	@Autowired
	UserRepo ur;
	
	@RequestMapping("/usign")
   public String userSign(@ModelAttribute User ob)
   {
		ur.save(ob);
		System.out.println(ob);
	    return "userLogin.jsp";
   }
   
   @RequestMapping("/userlogin")
   public String getloguser(@RequestParam String email,@RequestParam String password)
   {
	  User ob=ur.findByEmail(email);
	  if(ob!=null && ob.getEmail().equals(email) && ob.getPassword().equals(password))
	  {
		  return "redirect:/fetch";
	  }
	  else
	  {
		  return "userSign.jsp";
	  }
   }
   
   
}
